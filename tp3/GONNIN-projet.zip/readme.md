
liste des fonctions du projet:

-int max()				non parallelisée
-int add()				non parallelisée
-void printArray()			non parallelisée
-void allocateTablo()			non parallelisée
-void montee()				parallelisée
-void descente()			parallelisée
-void final()				parallelisée
-void parallel_maximum()		parallelisée
-void find_sequence()			non parallelisée
-void generateArray()			non parallelisée
-void montee_descente_final()		non parallelisée
-int main()				non parallelisée
